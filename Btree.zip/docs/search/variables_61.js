var searchData=
[
  ['accesses',['accesses',['../structbadgerdb_1_1_buf_stats.html#a3e7eb386ac728ed028bd2a8bb7960827',1,'badgerdb::BufStats']]],
  ['attrbyteoffset',['attrByteOffset',['../structbadgerdb_1_1_index_meta_info.html#aaa8448cef6016f7cba9cd2a76c77785f',1,'badgerdb::IndexMetaInfo']]],
  ['attrtype',['attrType',['../structbadgerdb_1_1_index_meta_info.html#af01a227a760221a57c3d3f4cbda0bbf1',1,'badgerdb::IndexMetaInfo']]]
];
