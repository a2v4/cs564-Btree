var searchData=
[
  ['indexmetainfo',['IndexMetaInfo',['../structbadgerdb_1_1_index_meta_info.html',1,'badgerdb']]],
  ['indexscancompletedexception',['IndexScanCompletedException',['../classbadgerdb_1_1_index_scan_completed_exception.html',1,'badgerdb']]],
  ['insufficientspaceexception',['InsufficientSpaceException',['../classbadgerdb_1_1_insufficient_space_exception.html',1,'badgerdb']]],
  ['invalidpageexception',['InvalidPageException',['../classbadgerdb_1_1_invalid_page_exception.html',1,'badgerdb']]],
  ['invalidrecordexception',['InvalidRecordException',['../classbadgerdb_1_1_invalid_record_exception.html',1,'badgerdb']]],
  ['invalidslotexception',['InvalidSlotException',['../classbadgerdb_1_1_invalid_slot_exception.html',1,'badgerdb']]]
];
